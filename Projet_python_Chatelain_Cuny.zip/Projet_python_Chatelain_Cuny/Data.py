# -*- coding: utf-8 -*-
"""
Created on Sun Jan  2 14:33:48 2022

@author: cunye
"""

import pandas as pd
import sklearn
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import sklearn
import joblib
import sklearn.neighbors
import sklearn.ensemble
import seaborn as sns
from flask import Flask

### Data

df=pd.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/00254/biodeg.csv', sep=';', header=None)
y=df
df[41].replace({"RB": 0, "NRB": 1}, inplace=True)

features=range(0,41)
X=df.loc[:, features].values
Y=df.loc[:, [41]].values


Y=np.ravel(Y)
X=StandardScaler().fit_transform(X)
X_train, X_test,Y_train,Y_test=train_test_split(X, Y, test_size= 0.2)

val_score=[]
for k in ['linear', 'poly', 'rbf', 'sigmoid']:
  score=sklearn.model_selection.cross_val_score(sklearn.svm.SVC(kernel=k),X_train,Y_train, cv=5, scoring='accuracy').mean()
  val_score.append(score)
  if score==max(val_score):
    bestKernel=k
plt.plot(val_score)
print(k)
model=sklearn.svm.SVC(kernel=bestKernel)
model.fit(X_train, Y_train)
print('train score',model.score(X_train, Y_train))
print('test score', model.score(X_test, Y_test))



model_filename = 'data-v1.pkl'
print("Saving model to {}...".format(model_filename))
joblib.dump(model, model_filename)