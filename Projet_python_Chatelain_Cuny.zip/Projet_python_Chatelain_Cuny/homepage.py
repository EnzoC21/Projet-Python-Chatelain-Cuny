# -*- coding: utf-8 -*-
"""
Created on Sun Jan  2 15:53:54 2022

@author: cunye
"""

from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler
app = Flask(__name__)


@app.route('/')
def home():
    return render_template('entre.html')


@app.route('/predict/', methods=['GET','POST'])
def predict():
    
    if request.method == "POST":
        #get form data
                    SpMax_L = request.form.get('SpMax_L')
                    J_Dz = request.form.get('J_Dz')
                    nHM = request.form.get('nHM')
                    F01 = request.form.get('F01')
                    F04 = request.form.get('F04')
                    NssssC = request.form.get('NssssC')
                    nCb = request.form.get('nCb')
                    C = request.form.get('C')
                    nCp = request.form.get('nCp')
                    nO = request.form.get('nO')
                    F03 = request.form.get('F03')
                    SdssC = request.form.get('SdssC')
                    HyWi_B = request.form.get('HyWi_B')
                    LOC = request.form.get('LOC')
                    SM6_L = request.form.get('SM6_L')
                    F03o = request.form.get('F03o')
                    Me = request.form.get('Me')
                    Mi = request.form.get('Mi')
                    nN_N = request.form.get('nN_N')
                    nArNO2 = request.form.get('nArNO2')
                    nCRX3 = request.form.get('nCRX3')
                    SpPosA_B = request.form.get('SpPosA_B')
                    nCIR = request.form.get('nCIR')
                    B01 = request.form.get('B01')
                    B03 = request.form.get('B03')
                    N_073 = request.form.get('N_073')
                    SpMax_A = request.form.get('SpMax_A')
                    Psi_i_1d = request.form.get('Psi_i_1d')
                    B04 = request.form.get('B04')
                    SdO = request.form.get('SdO')
                    TI2_L = request.form.get('TI2_L')
                    nCrt = request.form.get('nCrt')
                    C_026 = request.form.get('C_026')
                    F02 = request.form.get('F02')
                    nHDon = request.form.get('nHDon')
                    SpMax_B = request.form.get('SpMax_B')
                    Psi_i_A = request.form.get('Psi_i_A')
                    nN = request.form.get('nN')
                    SM6_B = request.form.get('SM6_B')
                    nArCOOR = request.form.get('nArCOOR')
                    nX = request.form.get('nX')
                    
                    prediction = preprocessDataAndPredict(SpMax_L, J_Dz,  nHM,  F01, F04, NssssC, nCb, C,  nCp, nO, F03, SdssC, HyWi_B, LOC, SM6_L, F03o, Me, Mi, nN_N, nArNO2, nCRX3, SpPosA_B, nCIR, B01,  B03,  N_073, SpMax_A, Psi_i_1d, B04, SdO, TI2_L, nCrt, C_026, F02, nHDon, SpMax_B, Psi_i_A, nN, SM6_B, nArCOOR, nX)
                    
                    return render_template('predict.html', prediction = prediction)
                    
                    
                   
                 
                  
               

def preprocessDataAndPredict(SpMax_L, J_Dz,  nHM,  F01, F04, NssssC, nCb, C,  nCp, nO, F03, SdssC, HyWi_B, LOC, SM6_L, F03o, Me, Mi, nN_N, nArNO2, nCRX3, SpPosA_B, nCIR, B01,  B03,  N_073, SpMax_A, Psi_i_1d, B04, SdO, TI2_L, nCrt, C_026, F02, nHDon, SpMax_B, Psi_i_A, nN, SM6_B, nArCOOR, nX):
    
    #keep all inputs in array
    test_data = [SpMax_L, J_Dz,  nHM,  F01, F04, NssssC, nCb, C,  nCp, nO, F03, SdssC, HyWi_B, LOC, SM6_L, F03o, Me, Mi, nN_N, nArNO2, nCRX3, SpPosA_B, nCIR, B01,  B03,  N_073, SpMax_A, Psi_i_1d, B04, SdO, TI2_L, nCrt, C_026, F02, nHDon, SpMax_B, Psi_i_A, nN, SM6_B, nArCOOR, nX]
    
    
   
    
    test_data = pd.DataFrame(data=test_data).T

    #open file
    file = open("data-v1.pkl","rb")
    
     #load trained model
    trained_model = joblib.load(file)
    
    #predict
    prediction = trained_model.predict(test_data)
    
    
    if prediction == 0 :
        prediction = "ready biodegradable"
    else :
        prediction = " non ready biodegradable"
        
    return prediction
    
    
    
  
if __name__ == '__main__':
    app.run(debug=True)