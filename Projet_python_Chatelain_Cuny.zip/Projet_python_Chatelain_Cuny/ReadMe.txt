Readme

1/open the notebook with jupyter 
2/run the notebook and see the path to the best model
3/Download the zip of the API
4/open it with spyder
5/run the homepage.py
6/go http://127.0.0.1:5000/
7/enter the molecule data
8/press the predict button
          